using Microsoft.VisualStudio.TestTools.UnitTesting;
using KalkulatorBiblioteka;

namespace KalkulatorBibliotekaTestProject
{
    [TestClass]
    public class UnitTest1
    {
        [TestMethod]
        public void TestMethod1()
        {
            int num1 = 4;
            int num2 = 5;
            Kalkulator k = new Kalkulator();

            Assert.AreNotEqual(num1, num2, "Nie rowne");
            Assert.IsNotNull(num1, "Prawda");
            Assert.IsNotNull(num2, "Prawda");
        }
    }
}
