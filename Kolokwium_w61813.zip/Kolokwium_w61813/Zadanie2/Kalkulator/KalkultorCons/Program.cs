﻿using System;
using KalkulatorBiblioteka;

namespace KalkultorCons
{
    class Program
    {
        static void Main(string[] args)
        {
            {
                Kalkulator k = new Kalkulator();
                Console.WriteLine(k.Square(12));
                Console.WriteLine(k.Add(8, 63));
                Console.WriteLine(k.Multiply(5, 8));
                Console.WriteLine(k.Subtract(10, 42));
                Console.WriteLine(k.Division(3, 4));
            }
        }
    }
}
